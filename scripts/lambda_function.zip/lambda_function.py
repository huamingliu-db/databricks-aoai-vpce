import boto3
import os

def lambda_handler(event, context):
    # Create a new EC2 client
    ec2_client = boto3.client('ec2')
    as_client = boto3.client('autoscaling')
    
    # get the list of all available Elastic IPs from EIP pool
    eips = ec2_client.describe_addresses(Filters=[{'Name': 'tag-key', 'Values': [os.environ['EIP_TAG_KEY']]}])
    print(eips)
    aval_eips = [eip for eip in eips['Addresses'] if 'AssociationId' not in eip]
    print(aval_eips)
    
    if not aval_eips:
        raise Exception('No free EIPs available')
        
    instance_id = event['detail']["EC2InstanceId"]
    eip = aval_eips[0]['AllocationId']
    
#    print(eip)
    ec2_client.associate_address(AllocationId=eip, InstanceId=instance_id)
    

    response = as_client.complete_lifecycle_action(
        LifecycleHookName =event['detail']["LifecycleHookName"],
        AutoScalingGroupName=event['detail']['AutoScalingGroupName'],
        LifecycleActionToken=event['detail']['LifecycleActionToken'],
        LifecycleActionResult='CONTINUE',  
        InstanceId=instance_id
        )